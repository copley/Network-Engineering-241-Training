#include <stdio.h>


void nowhere(int **p) {

    *p = NULL;

}


void main(void) {

    int a = 123;
    int *p = &a;

    printf(p == NULL ? "nowhere\n" : "somewhere\n");
    nowhere(&p);
    printf(p == NULL ? "nowhere\n" : "somewhere\n");

}
