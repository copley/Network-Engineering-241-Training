#include <stdio.h>
main()
{
    int k[10] = {0,1,2,3};




    int a[5];//initialise array
    int i;
    for(i = 0;i<5;i++)
    {
       a[i]=i;
    }

    for(i = 0;i<5;i++)
    {
        printf("value in array %d\n",a[i]);
    }
}